module.exports = {

	messages: {
		userId:{
			type: 'int',
			required: true
		},
		user:{
			type:'string',
			required:true
		},
  		message:{
  			type:'string',
  			required:true
  		}

	}
};
